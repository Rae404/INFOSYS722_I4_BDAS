"""Presentation only: typeset the preserved native tree; no fitting or prediction."""
from pathlib import Path
import json,hashlib,textwrap
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor,black
W=Path(__file__).parent;F=W/'current_figures';src=F/'decision_tree_native_nodes.jsonl'
nodes={r['id']:r for r in map(json.loads,src.read_text().splitlines())};assert len(nodes)==13
prep=json.loads((W/'complete_native/preparation/preparation_receipt.json').read_text())
names={a['idx']:(prep['numeric_inputs'][a['idx']] if a['idx']<9 else a['name']) for a in prep['feature_attributes']}
positions={};leaves=[0]
def position(k,depth=0):
 n=nodes[k]
 if n['leftChild']==-1:y=leaves[0];leaves[0]+=1
 else:
  assert nodes[n['leftChild']]['rawCount']+nodes[n['rightChild']]['rawCount']==n['rawCount']
  y=(position(n['leftChild'],depth+1)+position(n['rightChild'],depth+1))/2
 positions[k]=(depth,y);return y
position(0);assert len(positions)==13 and leaves[0]==7 and nodes[0]['rawCount']==7878
pdf=F/'F11_actual_decision_tree_presentation_v2.pdf';c=canvas.Canvas(str(pdf),pagesize=(660,710));c.setTitle('Baseline fitted decision tree from preserved Spark nodes');c.setAuthor('')
c.setFont('Helvetica-Bold',16);c.drawCentredString(330,680,'Baseline fitted decision tree')
c.setFont('Helvetica',11);c.drawCentredString(330,660,'Depth 4, 13 nodes; numeric thresholds use training SD units')
def coord(k):
 x,y=positions[k];return 69+x*126,600-y*85
# Put the condition meaning in an explicit line-style legend, avoiding overlapping edge labels.
for k,n in nodes.items():
 if n['leftChild']!=-1:
  x,y=coord(k)
  for child,truth in [(n['leftChild'],True),(n['rightChild'],False)]:
   xx,yy=coord(child);c.setStrokeColor(HexColor('#7A7A7A'));c.setLineWidth(1.15);c.setDash([] if truth else [5,3]);c.line(x,y,xx,yy)
c.setDash([])
for k,n in nodes.items():
 x,y=coord(k)
 if n['leftChild']==-1:
  lines=['Leaf '+str(k),'Purchase' if n['prediction']==1 else 'No purchase','n = '+format(n['rawCount'],',')]
  fill='#F2DEC8' if n['prediction']==1 else '#E6ECF1'
 else:
  split=n['split'];name=names[split['featureIndex']].replace('VisitorType_ohe_New_Visitor','New visitor').replace('Month_ohe_Nov','November').replace('log_ProductRelated_Duration','log1p duration').replace('Administrative_Duration','Administrative duration')
  cond=('<= '+format(split['leftCategoriesOrThreshold'][0],'.4g') if split['numCategories']==-1 else 'in {'+', '.join(format(v,'.4g') for v in split['leftCategoriesOrThreshold'])+'}')
  lines=['Node '+str(k)]+textwrap.wrap(name,18)+[cond,'n = '+format(n['rawCount'],',')];fill='#E6ECF1'
 width=112;height=16+len(lines)*13
 c.setFillColor(HexColor(fill));c.setStrokeColor(HexColor('#777777'));c.setLineWidth(.75);c.roundRect(x-width/2,y-height/2,width,height,5,fill=1,stroke=1)
 c.setFillColor(black);c.setFont('Helvetica',11.5)
 for j,line in enumerate(lines):c.drawCentredString(x,y+(len(lines)-1)*6.5-j*13-4,line)
c.setStrokeColor(HexColor('#555555'));c.setLineWidth(1.15);c.line(90,43,135,43);c.setFillColor(black);c.setFont('Helvetica',11);c.drawString(143,39,'Condition true')
c.setDash([5,3]);c.line(330,43,375,43);c.setDash([]);c.drawString(383,39,'Condition false')
c.setFont('Helvetica',10);c.drawCentredString(330,19,'Indicator value 1 means present; n is the raw training count. Leaf classes use weighted fitting.')
c.showPage();c.save()
receipt=dict(presentation_only=True,model_refit=False,prediction_recomputed=False,source_file=src.name,source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),node_count=13,leaf_count=7,raw_rows=7878,change='Replace overlapping Yes/No edge words with explicit solid/dashed condition legend; native rules, predictions and counts unchanged.',renderer='Python ReportLab; preserved Spark node JSON')
(F/'tree_presentation_receipt.json').write_text(json.dumps(receipt,indent=2))
print(str(pdf))
