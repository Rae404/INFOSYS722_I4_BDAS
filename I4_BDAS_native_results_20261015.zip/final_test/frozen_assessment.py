def assess_frozen_test(predictions):
    n=predictions.count()
    assert n==2477
    assert predictions.filter(F.col('score').isNull() | F.isnan('score') |
        (F.col('score')<0) | (F.col('score')>1)).count()==0
    counts={(int(r['label']),int(r['prediction'])):int(r['count'])
        for r in predictions.groupBy('label','prediction').count().collect()}
    tn,fp,fn,tp=[counts.get(p,0) for p in [(0,0),(0,1),(1,0),(1,1)]]
    purchases=tp+fn
    assert tn+fp+fn+tp==2477 and purchases==381
    precision=tp/(tp+fp) if tp+fp else 0.
    recall=tp/purchases
    f1=2*precision*recall/(precision+recall) if precision+recall else 0.
    auc={m:BinaryClassificationEvaluator(labelCol='label',rawPredictionCol='score',
         metricName=m,numBins=0).evaluate(predictions) for m in ['areaUnderROC','areaUnderPR']}
    k=math.ceil(.20*n)
    top=predictions.orderBy(F.desc('score'),'profile_id').limit(k)
    selected_buyers=int(top.agg(F.sum('label')).first()[0])
    cutoff=min(r['score'] for r in top.select('score').collect())
    return dict(variant='random_forest',split='test',rows=n,purchases=purchases,
        TN=tn,FP=fp,FN=fn,TP=tp,precision=precision,recall=recall,F1=f1,accuracy=(tn+tp)/n,
        **auc,selected_rows=k,selected_buyers=selected_buyers,recall_at_20=selected_buyers/purchases,
        precision_at_20=selected_buyers/k,lift_at_20=(selected_buyers/k)/(purchases/n),
        cutoff_score=cutoff,cutoff_ties=predictions.filter(F.col('score')==cutoff).count(),
        score_tie_policy='score descending, profile_id ascending; no label used')
