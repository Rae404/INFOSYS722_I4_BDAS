def prepare_frozen_input(frame):
    cats=['Month','OperatingSystems','Browser','Region','TrafficType','VisitorType','Weekend']
    nums=['Administrative','Administrative_Duration','Informational','Informational_Duration',
          'ProductRelated','BounceRates','ExitRates','SpecialDay']
    return frame.select('profile_id','label',
        *[F.trim(F.col(c).cast('string')).alias(c) for c in cats],
        *[F.col(c).cast('double').alias(c) for c in nums],
        F.log1p(F.col('ProductRelated_Duration')).alias('log_ProductRelated_Duration'))
